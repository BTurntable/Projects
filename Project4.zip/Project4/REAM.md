/*date: 12/06/19
* name: Brady Turner
* turne948 */



Brady Turner    turne948

How to compile:

To compile the server, execute make server with the server folder open on the terminal
To compile the client, execute make client with the client folder open on the terminal


How to run the:

The client:
	./client <folder name> <#of mappers> <server IP> <server port>

The server:
	./server <server port>

I had no partner

I did not attempt extra credit.

struct letterCount
{
    char letter[2];
    int count;
};

struct updateStatusTable
{
    int mapperID;
    int numOfUpdates;
    int checkFlag;
};

struct threadArg {
	int clientfd;
	char * clientip;
	int clientport;
};

void init_letterCount(struct letterCount *thing);
void find_incriment_letter(struct letterCount *thing, char *word);
int searchTable(struct updateStatusTable *tab, int id);


/*date: 12/06/19
* name: Brady Turner
* turne948 */


#include <stdio.h>
#include <netdb.h>
#include <netinet/in.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
//#include "zconf.h"
#include <pthread.h>
#include <signal.h>
#include <arpa/inet.h>
#include"../include/utils.h"
#include "../include/protocol.h"



struct letterCount *azList;
struct updateStatusTable *updateStatus;
int table_count;

pthread_mutex_t tab_count_mut;
pthread_mutex_t az_mut;
pthread_mutex_t update_mut;

//This function searches the StatusTable for the given mapper
int searchTable(struct updateStatusTable *tab, int id)
{
    int i;
    
    for(i = 0; i<table_count; i++)
    {
        if((tab+i) ->mapperID == id)
            return i;
    }
    
    return -99999;
}


//Initializes an array of 26 letterCount structs, one for each letter
void init_letterCount(struct letterCount *thing)
{
	int j;
	for (j = 0; j < 26; j++)
	{
        char ascii[2];
        ascii[0]= 65 + j;
        ascii[1] = '\0';

        strcpy((thing+j) -> letter, ascii);
		(thing+j) -> count = 0;
	}
}
//Thread functionality
void * threadFunction(void * arg)
{
    struct threadArg *targ = (struct threadArg *) arg;
    int response[28];
    int request[28];
    int u;

    read(targ->clientfd, request, sizeof(int)*28);


    if(request[0] != CHECKIN)
    {
        response[0] = request[0];
        response[1] = RSP_NOK;
        for(u=2; u<28; u++)
        {
            response[u] = 0;
        }
        response[2] = request[1];
        
        perror("Mapper is not checked in error");

        write(targ->clientfd, response, sizeof(int)*28);
        close(targ->clientfd);
        return NULL;
        
    }
    else
    {
        printf("[%d] CHECKIN\n", request[1]);
        response[0] = request[0];
        response[1] = RSP_OK;
        for(u=2; u<28; u++)
        {
            response[u] = 0;
        }

        response[2] = request[1];
        write(targ->clientfd, response, sizeof(int)*28);

        pthread_mutex_lock(&update_mut);
        (updateStatus+table_count) ->checkFlag = 1;
        (updateStatus+table_count) ->mapperID = request[1];
        (updateStatus+table_count) ->numOfUpdates = 0;
        struct updateStatusTable *threadsEntry = (updateStatus+table_count);
        pthread_mutex_unlock(&update_mut);


        
        pthread_mutex_lock(&tab_count_mut);
        table_count++;
        pthread_mutex_unlock(&tab_count_mut);
        

        
        pthread_mutex_lock(&update_mut);
        while(threadsEntry->checkFlag != 0)
        {

            pthread_mutex_unlock(&update_mut);
            
            read(targ->clientfd, request, sizeof(int)*28);


            pthread_mutex_lock(&update_mut);
            if(searchTable(updateStatus, request[1]) == -99999)
            {
                pthread_mutex_unlock(&update_mut);
                printf("Error: There is no table entry for the given mapper id\n");
                response[0] = request[0];
                response[1] = RSP_NOK;
                for(u=2; u<28; u++)
                {
                    response[u] = 0;
                }
                response[2] = request[1];
                write(targ->clientfd, response, sizeof(int)*28);
                
                continue;
            }
            pthread_mutex_unlock(&update_mut);

            if(request[1] <= 0)
            {
                printf("Error: Invalid mapper id (less than 0)\n");
                response[0] = request[0];
                response[1] = RSP_NOK;
                for(u=2; u<28; u++)
                {
                    response[u] = 0;
                }
                response[2] = request[1];
                write(targ->clientfd, response, sizeof(int)*28);
                
                continue;


            }
            
            if(request[0] == UPDATE_AZLIST)
            {

                pthread_mutex_lock(&update_mut);
                int id = searchTable(updateStatus, request[1]);
                pthread_mutex_unlock(&update_mut);
                
                int j;
                pthread_mutex_lock(&az_mut);
                for(j=0; j<26; j++)
                {
                    
                    (azList+j) ->count += request[j+2];
                    
                }
                pthread_mutex_unlock(&az_mut);


                pthread_mutex_lock(&update_mut);
                ((updateStatus+id) ->numOfUpdates)++;
                pthread_mutex_unlock(&update_mut);
                

                response[0] = UPDATE_AZLIST;
                response[1] = RSP_OK;
                for(u=2; u<28; u++)
                {
                    response[u] = 0;
                }
                response[2] = request[1];
                write(targ->clientfd, response, sizeof(int)*28);

            }
            else if(request[0] == GET_AZLIST)
            {
                printf("[%d] GET_AZLIST\n", request[1]);

                response[0] = GET_AZLIST;
                response[1] = RSP_OK;
                pthread_mutex_lock(&az_mut);
                for(u=2; u<28; u++)
                {
                    response[u] = (azList+u-2)->count;
                }
                pthread_mutex_unlock(&az_mut);
                write(targ->clientfd, response, sizeof(int)*28);
            }
            else if(request[0] == GET_MAPPER_UPDATES)
            {
                printf("[%d] GET_MAPPER_UPDATES\n", request[1]);

                pthread_mutex_lock(&update_mut);
                int id = searchTable(updateStatus, request[1]);
                response[2] = (updateStatus+id) ->numOfUpdates;
                pthread_mutex_unlock(&update_mut);


                response[0] = GET_MAPPER_UPDATES;
                response[1] = RSP_OK;
                for(u=3; u<28; u++)
                {
                    response[u] = 0;
                }
                write(targ->clientfd, response, sizeof(int)*28);
            }
            else if(request[0] == GET_ALL_UPDATES)
            {
                printf("[%d] GET_ALL_UPDATES\n", request[1]);

                pthread_mutex_lock(&tab_count_mut);
                int num = table_count;
                pthread_mutex_unlock(&tab_count_mut);
                

                int total = 0;
                pthread_mutex_lock(&update_mut);
                for(u=0; u<num; u++)
                {
                    total += (updateStatus+u) ->numOfUpdates;
                }
                pthread_mutex_unlock(&update_mut);
                response[0] = GET_ALL_UPDATES;
                response[1] = RSP_OK;
                for(u=2; u<28; u++)
                {
                    response[u] = 0;
                }
                response[2] = total;

                write(targ->clientfd, response, sizeof(int)*28);
                
            }
            else if(request[0] == CHECKOUT)
            {
                printf("[%d] CHECKOUT\n", request[1]);

                pthread_mutex_lock(&update_mut);
                int id = searchTable(updateStatus, request[1]);
                pthread_mutex_unlock(&update_mut);

                pthread_mutex_lock(&update_mut);
                if((updateStatus+id)->checkFlag == 0)
                {
                    pthread_mutex_unlock(&update_mut);
                    printf("Error: Mapper %d is not checked in\n", request[1]);
                    response[0] = request[0];
                    response[1] = RSP_NOK;
                    for(u=2; u<28; u++)
                    {
                        response[u] = 0;
                    }
                    response[2] = request[1];
                    write(targ->clientfd, response, sizeof(int)*28);
                    
                    continue;
                }
                pthread_mutex_unlock(&update_mut);

                response[0] = CHECKOUT;
                response[1] = RSP_OK;
                for(u=2; u<28; u++)
                {
                    response[u] = 0;
                }
                response[2] = request[1];
                write(targ->clientfd, response, sizeof(int)*28);
                
                pthread_mutex_lock(&update_mut);
                (updateStatus+id)->checkFlag = 0;
                pthread_mutex_unlock(&update_mut);

                close(targ->clientfd);
            }
            else if(request[0] == CHECKIN)
            {
                printf("[%d] CHECKIN\n", request[1]);
                pthread_mutex_lock(&update_mut);
                int id = searchTable(updateStatus, request[1]);
                pthread_mutex_unlock(&update_mut);

                response[0] = request[0];
                for(u=2; u<28; u++)
                {
                    response[u] = 0;
                }
                response[2] = request[1];
                pthread_mutex_lock(&update_mut);
                if((updateStatus+id)->checkFlag == 1)
                {
                    pthread_mutex_unlock(&update_mut);
                    printf("Mapper %d is already checked in\n", request[1]);
                    response[1] = RSP_NOK;
                    write(targ->clientfd, response, sizeof(int)*28);
                    
                    continue;
                }      
                else
                {
                    (updateStatus+id)->checkFlag = 1;
                    pthread_mutex_unlock(&update_mut);
                    response[1] = RSP_OK;
                    write(targ->clientfd, response, sizeof(int)*28);
                }
            }
            else
            {
                printf("Error: Unknown request code\n");
                response[0] = request[0];
                response[1] = RSP_NOK;
                for(u=2; u<28; u++)
                {
                    response[u] = 0;
                }
                response[2] = request[1];
                write(targ->clientfd, response, sizeof(int)*28);
                
                continue;
            }
            


            pthread_mutex_lock(&update_mut);
        }
        pthread_mutex_unlock(&update_mut);
        

    }

    return NULL;
    
}



int main(int argc, char *argv[]) {

    int server_port;
    
    if (argc == 2) { // 1 arguments
        server_port = atoi(argv[1]);
    } else {
        printf("Invalid or less number of arguments provided\n");
        printf("./server <server Port>\n");
        exit(0);
    }
    pthread_t threads[50];
	int count = 0;
	

    pthread_mutex_init(&az_mut, NULL);
    pthread_mutex_init(&update_mut, NULL);
    pthread_mutex_init(&tab_count_mut, NULL);
    azList = malloc(sizeof(struct letterCount) * 26);
    init_letterCount(azList);
    updateStatus = malloc(sizeof(struct updateStatusTable)*50);
    table_count=0;

    
	int sock = socket(AF_INET , SOCK_STREAM , 0);

	struct sockaddr_in servAddress;
	servAddress.sin_family = AF_INET;
	servAddress.sin_port = htons(server_port);
	servAddress.sin_addr.s_addr = htonl(INADDR_ANY);
	bind(sock, (struct sockaddr *) &servAddress, sizeof(servAddress));

    listen(sock, 50);
    printf("server is listening\n");

    while (1) 
    {
	    struct sockaddr_in clientAddress;

		socklen_t size = sizeof(struct sockaddr_in);
		int clientfd = accept(sock, (struct sockaddr*) &clientAddress, &size);
        

        struct threadArg *arg = (struct threadArg *) malloc(sizeof(struct threadArg));
		
		arg->clientfd = clientfd;
		arg->clientip = inet_ntoa(clientAddress.sin_addr);
		arg->clientport = clientAddress.sin_port;
        printf("open conection from %s: %d\n", arg->clientip, arg->clientport);
        pthread_create(&threads[count++], NULL, threadFunction, (void *) arg);
        
	}



    return 0;
} 
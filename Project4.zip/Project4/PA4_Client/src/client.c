/*date: 12/06/19
* name: Brady Turner
* turne948 */



#define _BSD_SOURCE

#define _DEFAULT_SOURCE

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include "zconf.h"
#include <signal.h>
#include <arpa/inet.h>
#include <ctype.h>
#include <errno.h>
#include "../include/protocol.h"

FILE *logfp;

struct letterCount
{
    char letter[2];
    int count;
};

//Helper for parseFile
char * removeLastChar(char* line)
{
	int length = strlen(line);

	line[length -1] = '\0';

	return line;
}

//Find which letter to incriment
void find_incriment_letter(struct letterCount *thing, char *word)
{
    int j;
    for(j = 0; j < 26; j++)
    {
        if(strncasecmp((thing+j)->letter, word, 1) == 0)
        {
            ((thing+j) -> count)++;
            return;
        }
    }
}

//Initializes an array of 26 letterCount structs, one for each letter
void init_letterCount(struct letterCount *thing)
{
	int j;
	for (j = 0; j < 26; j++)
	{
        char ascii[2];
        ascii[0]= 65 + j;
        ascii[1] = '\0';

        strcpy((thing+j) -> letter, ascii);
		(thing+j) -> count = 0;
	}
}

//Function to parse each individual text file and call find_incriment_letter on each word in the file
struct letterCount * parseFile(char * filePath)
{
	struct letterCount *countArray = malloc(sizeof(struct letterCount) * 26);
	init_letterCount(countArray);
	filePath = removeLastChar(filePath);

	FILE *fp = fopen(filePath, "r");
	if(fp == NULL)
	{
		printf("%s", strerror(errno));
	}

	char * word = malloc(sizeof(char) * 100);
	while(fgets(word, 100, fp) != NULL)
	{
		find_incriment_letter(countArray, word);
	}
	fclose(fp);
	return countArray;
}


void createLogFile(void) {
    pid_t p = fork();
    if (p==0)
        execl("/bin/rm", "rm", "-rf", "log", NULL);

    wait(NULL);
    mkdir("log", ACCESSPERMS);
    logfp = fopen("log/log_client.txt", "w");
}

int main(int argc, char *argv[]) {
    int mappers;
    char folderName[100] = {'\0'};
    char *server_ip;
    int server_port;


    if (argc == 5) { // 4 arguments
        strcpy(folderName, argv[1]);
        mappers = atoi(argv[2]);
        server_ip = argv[3];
        server_port = atoi(argv[4]);
        if (mappers > MAX_MAPPER_PER_MASTER) {
            printf("Maximum number of mappers is %d.\n", MAX_MAPPER_PER_MASTER);
            printf("./client <Folder Name> <# of mappers> <server IP> <server Port>\n");
            exit(1);
        }

    } else {
        printf("Invalid or less number of arguments provided\n");
        printf("./client <Folder Name> <# of mappers> <server IP> <server Port>\n");
        exit(1);
    }

    // create log file
    createLogFile();

    // phase1 - File Path Partitioning
    traverseFS(mappers, folderName);

    // Phase2 - Mapper Clients's Deterministic Request Handling
    int sockfd[mappers];
    int n;
    for(n=0; n<mappers;n++)
    {
        sockfd[n] = socket(AF_INET , SOCK_STREAM , 0);
    }

	
	struct sockaddr_in address;
	address.sin_family = AF_INET;
	address.sin_port = htons(server_port);
	address.sin_addr.s_addr = inet_addr(server_ip);
    
    int i;
    pid_t pid;
    pid_t *pids = malloc(sizeof(pid_t)*mappers);
    for(i = 0; i < mappers; i++)
    {
        pid = fork();
        if(pid == 0)
        {
            int request[28];
            int response[28];
            struct letterCount *processCount;

            
            FILE *input;
            char * inFile = malloc(sizeof(char)*1000);
            getcwd(inFile, 1000);

            
            strcat(inFile, "/MapperInput/Mapper_");
            char id[5];
            sprintf(id, "%d", i+1);
            strcat(inFile, id);
            strcat(inFile, ".txt");
            
            if ((input = fopen(inFile, "r")) == NULL)
			{
				printf("1Error %d\n", errno);
                exit(0);

			}
            else
            {
                int u;
                
                if (connect(sockfd[i], (struct sockaddr *) &address, sizeof(address)) == 0)
                {
                    
                    fprintf(logfp, "[%d] open connection\n", i+1);

                    request[0] = CHECKIN;
                    request[1] = i+1;
                    
                    for(u=2; u<28; u++)
                    {
                        request[u] = 0;
                    }

                    write(sockfd[i], request, sizeof(int)*28);
                    read(sockfd[i], response, sizeof(int)*28);
                    fprintf(logfp, "[%d] CHECKIN: %d %d\n", i+1, response[1], response[2]);

                    char *line = malloc(sizeof(char)*500);
                    

                    int l = 0;
                    while (fgets(line, 500, input) != NULL)
                    {
                        processCount = parseFile(line);
                        request[0] = UPDATE_AZLIST;
                        request[1] = i+1;
                        int j;
                        for(j = 2; j<28; j++)
                        {
                            request[j] = (processCount + j - 2) ->count;
                        }

                        write(sockfd[i], request, sizeof(int)*28);
                        read(sockfd[i], response, sizeof(int)*28);
                        l++;

                    }
                    fprintf(logfp, "[%d] UPDATE_AZLIST: %d\n", i+1, l);

                    request[0] = GET_AZLIST;
                    request[1] = i+1;
                    for(u=2; u<28; u++)
                    {
                        request[u] = 0;
                    }
                    write(sockfd[i], request, sizeof(int)*28);
                    read(sockfd[i], response, sizeof(int)*28);
                    char AZCount[52] = {'\0'};
                    int k;
                    char buf[10];
                    for(k = 0; k<25; k++)
                    {
                        snprintf(buf, 10, "%d", response[k+2]);

                        strcat(AZCount, buf);
                        strcat(AZCount, " ");
                    }

                    snprintf(buf, 10, "%d", response[k+2]);
                    strcat(AZCount, buf);
                    fprintf(logfp, "[%d] GET_AZLIST: %d %s\n", i+1, response[1], AZCount);

                    request[0] = GET_MAPPER_UPDATES;
                    request[1] = i+1;
                    for(u=2; u<28; u++)
                    {
                        request[u] = 0;
                    }
                    write(sockfd[i], request, sizeof(int)*28);
                    read(sockfd[i], response, sizeof(int)*28);
                    fprintf(logfp, "[%d] GET_MAPPER_UPDATES: %d %d\n", i+1, response[1], response[2]);

                    request[0] = GET_ALL_UPDATES;
                    request[1] = i+1;
                    for(u=2; u<28; u++)
                    {
                        request[u] = 0;
                    }
                    write(sockfd[i], request, sizeof(int)*28);
                    read(sockfd[i], response, sizeof(int)*28);
                    fprintf(logfp, "[%d] GET_ALL_UPDATES: %d %d\n", i+1, response[1], response[2]);

                    request[0] = CHECKOUT;
                    request[1] = i+1;
                    for(u=2; u<28; u++)
                    {
                        request[u] = 0;
                    }
                    write(sockfd[i], request, sizeof(int)*28);
                    read(sockfd[i], response, sizeof(int)*28);
                    fprintf(logfp, "[%d] CHECKOUT: %d %d\n", i+1, response[1], response[2]);

                    close(sockfd[i]);
                    fprintf(logfp, "[%d] close connection\n", i+1);
                    
                    exit(0);
                }
                else
                {
                    perror("connection failed");
                    printf("%d", errno);
                    exit(0);
                }
                
            }
           
        }
        else
        {
            pids[i] = pid;
        }
        

    }
    int f;
    for (f = 0; f<mappers; f++)
    {
        int status;
        wait(pids[f], &status, 0);
    }
    

    fclose(logfp);
    return 0;

}
